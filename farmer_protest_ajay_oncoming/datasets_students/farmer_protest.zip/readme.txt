Give label 0 for those who are against of farmer protest or supporting the farm bills
Give label 1 for those who are in support of farmer protest or against the farm bills

You can delete an ambiguous comment
Refer to random_sample.csv